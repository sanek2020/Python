# number = 3 < 5
# while number < 5:
#     print(f"number = {number}")
#     number += 1
# print("Работа программы завершена")
# print(f"number = {number}")
# number += 1
# number = 1
#
# while number < 5:
#     print(f"number = { number}")
#     number += 1
# else:
#     print(f"number = {number}. Работа цикла завершена")
# print("Работа цикла завершена")
import math
#
# a = -0.4 * math.pi
# b = 0.4 * math.pi
# h = 0.5
# Y=math.pow(a,2)*math.sqrt(15+10*math.sin(a+math.pi))
# while a < b:
#     Y = math.pow(a, 2) * math.sqrt(15 + 10 * math.sin(a + math.pi))
#     print(Y)
#     a += h